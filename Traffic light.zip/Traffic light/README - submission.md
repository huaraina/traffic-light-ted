# Traffic Light Project
[Github Link](https://github.com/huaraina/traffic-light-ted) <!---not updated, btw, ill do it later or something--->
R&D Research Project

## Files
1. light.ipt
2. Light - Fusion Convert v1.ipt
3. Light - Fusion Convert - Drawing.idw


### Purpose for files
- 1, original project file. made in inventor 2024, not usable on school desktops without fusion convert
- 2, fusion converted version of 1. most updated copy. made in inventor 2021/2023
- 3, orthographic & isometric drawings of the traffic signal head