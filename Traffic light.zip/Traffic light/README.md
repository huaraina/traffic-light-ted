# Traffic Light Project
[Github Link](https://github.com/huaraina/traffic-light-ted)
R&D Research Project

## Files
1. light.ipt
2. Light - Fusion Convert v1.ipt
3. Light - Fusion Convert - Drawing.idw
4. Traffic light.zip
5. OldVersions
6. 3d Printing files
7. Light - Fusion- Convert v1 - Copy.ipt
8. Light Drawing.pdf
9. README - submission.md

### Purpose for files
- 1, original project file. made in inventor 2024, not usable on school desktops without fusion convert
- 2, fusion converted version of 1. most updated copy. made in inventor 2021/2023
- 3, orthographic & isometric drawings of the traffic signal head
- 4, zip copy of the files. made on Oct 10 - 9:04 am. may not be updated
- 5, inventor files, idk what theyre for
- 6, files cut up for 3d printing
- 7, spare version for cutting up and printing
- 8, drawing exported as pdf
- 9, turn in copy of readme without excess files and stuff